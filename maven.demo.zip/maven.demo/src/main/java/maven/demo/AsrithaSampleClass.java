package maven.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AsrithaSampleClass {
	
	WebDriver driver = null;
	@Parameters("browserName")
	@BeforeTest
	public void setup(String browserName) {
		System.out.println("Browser name is : " +browserName);
		
		if(browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\eclipse\\maven.demo\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if(browserName.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "C:\\eclipse\\maven.demo\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
	}
	/*(1)Create a xpath or Css path for this Selectable Item and Click on each of the Items and print the Item Name*/
	@Test
	public void test() throws InterruptedException {
		JavascriptExecutor javascriptExecutor;
		javascriptExecutor = (JavascriptExecutor) driver;
		driver.manage().window().maximize();
		Thread.sleep(10000);
		
		driver.get("https://demoqa.com/selectable");
		driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[1]")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[1]")).getText());
		driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[2]")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[2]")).getText());
		driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[3]")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[3]")).getText());
		driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[4]")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[4]")).getText());
		driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[5]")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[5]")).getText());
		driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[6]")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[6]")).getText());
		driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[7]")).click();
		System.out.println(driver.findElement(By.xpath("//*[@id=\"selectable\"]/li[7]")).getText());


	/*(2)Please fill this contact form using CSS and Xpath*/
	
		driver.get("https://demoqa.com/html-contact-form/");
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[1]")).sendKeys("Asritha");
		driver.findElement(By.xpath("//*[@id=\"lname\"]")).sendKeys("Vardhini");
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[3]")).sendKeys("India");
		driver.findElement(By.linkText("Google Link")).sendKeys(Keys.CONTROL,Keys.RETURN);
		driver.findElement(By.linkText("Google Link is here")).sendKeys(Keys.CONTROL,Keys.RETURN);
		driver.findElement(By.xpath("//*[@id=\"subject\"]")).sendKeys("HTML Contact Form");
		driver.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[4]")).click();
	
	//(3)please select the Drag me to my target and drop on the target and verify the text
	
		driver.get("https://demoqa.com/droppable/");
		WebElement from = driver.findElement(By.xpath("//*[@id=\"draggable\"]/p"));
		WebElement to = driver.findElement(By.xpath("//*[@id=\"droppable\"]"));
		MyClass mc = new MyClass();
		Actions act=new Actions(driver);
		act.dragAndDrop(from, to).build().perform();
	
	//(4)Please select your Date of Birth in a Calendar.
	
		driver.get("https://demoqa.com/datepicker/");
		driver.findElement(By.xpath("//*[@id=\"datepicker\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"datepicker\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[3]/td[7]/a")).click();
	
	//(5)Please select the All the menu options one by one.
	
		driver.get("https://demoqa.com/selectmenu/");
		driver.findElement(By.xpath("//*[@id=\"speed-button\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"ui-id-5\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"files-button\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"ui-id-7\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"number-button\"]/span[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"ui-id-13\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"salutation-button\"]")).click();
		driver.findElement(By.xpath("//*[@id=\"ui-id-30\"]")).click();
	
	//(6)Please Automate Rental Car Block
	
		driver.get("https://demoqa.com/controlgroup/");
		
		driver.findElement(By.xpath("(//span[@class='ui-selectmenu-text'])[1]")).click();
		driver.findElement(By.xpath("//div[@id='ui-id-2']")).click();
		driver.findElement(By.xpath("(//label[@class='ui-button ui-widget ui-checkboxradio-label ui-controlgroup-item'])[1]")).click();		
		driver.findElement(By.xpath("(//*[@class='ui-spinner-input'])[1]")).sendKeys("5");
		
		driver.findElement(By.xpath("//button[@class='ui-widget ui-controlgroup-item ui-button ui-corner-right']")).click();
		
		javascriptExecutor.executeScript("window.scrollBy(200,300)");
		
		driver.findElement(By.xpath("(//span[@class='ui-selectmenu-text'])[2]")).click();
		driver.findElement(By.xpath("//div[@id='ui-id-10']")).click();
		driver.findElement(By.xpath("(//label[@class='ui-button ui-widget ui-checkboxradio-label ui-controlgroup-item'])[1]")).click();
		driver.findElement(By.xpath("(//*[@class='ui-spinner-input'])[2]")).sendKeys("5");
		
		
		driver.findElement(By.xpath("//button[@class='ui-widget ui-controlgroup-item ui-button ui-corner-right']")).click();
		
	
	
	//Assignment 2
		
		driver.get("https://www.olay.co.uk/en-gb");
		driver.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[2]")).click();
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[emails][0][address]\"]")).sendKeys("vardhini513@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][password]\"]")).sendKeys("asritha513");
		driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][confirm]\"]")).sendKeys("asritha513");
		driver.findElement(By.xpath("//select[@name='phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][day]']//option[30]")).click();
		driver.findElement(By.xpath("//select[@name='phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][month]']//option[8]")).click();
		driver.findElement(By.xpath("//select[@name='phdesktopbody_0$phdesktopbody_0_grs_consumer[birthdate][year]']//option[11]")).click();
		javascriptExecutor.executeScript("window.scrollBy(1,1000)");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		driver.findElement(By.xpath("//input[@data-key='firstName']")).sendKeys("Asritha");
		driver.findElement(By.xpath("//input[@data-key='lastName']")).sendKeys("Vardhini");
		driver.findElement(By.xpath("//input[@data-key='addressStreet1']")).sendKeys("Near Wipro Circle");
		driver.findElement(By.xpath("//input[@data-key='addressCity']")).sendKeys("Banglore");
		driver.findElement(By.xpath("//input[@data-key='addressPostalCode']")).sendKeys("522616");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		//Login
		driver.findElement(By.xpath("//input[@name='phdesktopbody_0$phdesktopbody_0_username']")).sendKeys("vardhini513@gmail.com");
		driver.findElement(By.xpath("//input[@name='phdesktopbody_0$phdesktopbody_0_password']")).sendKeys("522616");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
	
	//Assignment 3:
	
	driver.get("https://www.makemytrip.com/");
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[1]/ul/li[2]/span")).click();
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[1]/label/span")).click();
	driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-3\"]/div/div[1]/p[1]")).click();
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[2]/label/span")).click();
	driver.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-1\"]/div/div[1]")).click();
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/label/span")).click();
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[4]/div[2]/div/p")).click();
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[4]/label/span")).click();
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[4]/div[5]/div/p")).click();
	driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/p/a")).click();
	Thread.sleep(15000);
	driver.findElement(By.xpath("//button[@id='sorter_btn_onward']")).click();
	driver.findElement(By.xpath("(//span[@class='sortByRTname']//following-sibling:: *[@class='inlineB marL10 sortbytype'])[1]")).click();
	driver.findElement(By.xpath("//button[@id='sorter_btn_return']")).click();
	driver.findElement(By.xpath("(//span[@class='sortByRTname']//following-sibling:: *[@class='inlineB marL10 sortbytype'])[7]")).click();
	String departureValue=driver.findElement(By.xpath("(//div[@class='fli-list splitVw-listing active'])[1]//div[@class='pull-right marL5 text-right']//div/p/span[@class='actual-price']")).getText().substring(2);
	String returnValue=driver.findElement(By.xpath("(//div[@class='fli-list splitVw-listing active'])[2]//div[@class='pull-right marL5 text-right']//div/p/span[@class='actual-price']")).getText().substring(2);
	
	System.out.println(departureValue+" "+returnValue);
	driver.findElement(By.xpath("//button[@class='fli_primary_btn text-uppercase ']")).click();
	
	}
}
