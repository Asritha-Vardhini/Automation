package maven.demo;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class MyClass {
	public static void main(String a[]) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\lenovo\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver1 = new ChromeDriver();
		driver1.get("https://demoqa.com/selectable");
		
		/*String count = driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[1]"))*/
		
		/*(1)Create a xpath or Css path for this Selectable Item and Click on each of the Items and print the Item Name*/
		 
		driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[1]")).click();
		System.out.println(driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[1]")).getText());
		driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[2]")).click();
		System.out.println(driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[2]")).getText());
		driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[3]")).click();
		System.out.println(driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[3]")).getText());
		driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[4]")).click();
		System.out.println(driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[4]")).getText());
		driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[5]")).click();
		System.out.println(driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[5]")).getText());
		driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[6]")).click();
		System.out.println(driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[6]")).getText());
		driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[7]")).click();
		System.out.println(driver1.findElement(By.xpath("//*[@id=\"selectable\"]/li[7]")).getText());
		
		/*(2)Please fill this contact form using CSS and Xpath*/
		
		driver1.get("https://demoqa.com/html-contact-form/");
		driver1.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[1]")).sendKeys("Asritha");
		driver1.findElement(By.xpath("//*[@id=\"lname\"]")).sendKeys("Vardhini");
		driver1.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[3]")).sendKeys("India");
		driver1.findElement(By.linkText("Google Link")).sendKeys(Keys.CONTROL,Keys.RETURN);
		driver1.findElement(By.linkText("Google Link is here")).sendKeys(Keys.CONTROL,Keys.RETURN);
		/*driver1 = new ChromeDriver();
		driver1.manage().window().maximize();
		driver1.get("https://www.google.com/");
		String a1 = "window.open(//*[@id=\"content\"]/div[2]/div/form/a[1],'_blank');"; // replace link with your desired link
		((JavascriptExecutor)driver1).executeScript(a1);*/
		driver1.findElement(By.xpath("//*[@id=\"subject\"]")).sendKeys("HTML Contact Form");
		driver1.findElement(By.xpath("//*[@id=\"content\"]/div[2]/div/form/input[4]")).click();
		
		/*(3)please select the Drag me to my target and drop on the target and verify the text*/
		
		driver1.get("https://demoqa.com/droppable/");
		WebElement from = driver1.findElement(By.xpath("//*[@id=\"draggable\"]/p"));
		WebElement to = driver1.findElement(By.xpath("//*[@id=\"droppable\"]"));
		MyClass mc = new MyClass();
		Actions act=new Actions(driver1);
		act.dragAndDrop(from, to).build().perform();
		
		/*(4)Please select your Date of Birth in a Calendar.*/
		
		driver1.get("https://demoqa.com/datepicker/");
		driver1.findElement(By.xpath("//*[@id=\"datepicker\"]")).click();
		driver1.findElement(By.xpath("//*[@id=\"datepicker\"]")).click();
		driver1.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[3]/td[7]/a")).click();
		
		/*(5)Please select the All the menu options one by one.*/
		
		driver1.get("https://demoqa.com/selectmenu/");
		driver1.findElement(By.xpath("//*[@id=\"speed-button\"]")).click();
		driver1.findElement(By.xpath("//*[@id=\"ui-id-5\"]")).click();
		driver1.findElement(By.xpath("//*[@id=\"files-button\"]")).click();
		driver1.findElement(By.xpath("//*[@id=\"ui-id-7\"]")).click();
		driver1.findElement(By.xpath("//*[@id=\"number-button\"]/span[2]")).click();
		driver1.findElement(By.xpath("//*[@id=\"ui-id-13\"]")).click();
		driver1.findElement(By.xpath("//*[@id=\"salutation-button\"]")).click();
		driver1.findElement(By.xpath("//*[@id=\"ui-id-30\"]")).click();
		
		/*(6)Please Automate Rental Car Block
		
		driver1.get("https://demoqa.com/controlgroup/");*/
		
		
		/*Assignment 2*/
		driver1.get("https://www.olay.co.uk/en-gb");
		driver1.findElement(By.xpath("//*[@id=\"phdesktopheader_0_phdesktopheadertop_2_pnlCRMHeaderLink\"]/div/a[2]")).click();
		driver1.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[emails][0][address]\"]")).sendKeys("asritha123@gmail.com");
		driver1.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][password]\"]")).sendKeys("asritha513");
		driver1.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_account[password][confirm]\"]")).sendKeys("asritha513");
		driver1.findElement(By.xpath("//*[@id=\"phdesktopbody_0_grs_consumer[birthdate][day]\"]")).sendKeys("10");
		
		
		
		
		
		/*Assignment 3:
		
		driver1.get("https://www.makemytrip.com/");
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[1]/ul/li[2]/span")).click();
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[1]/label/span")).click();
		driver1.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-3\"]/div/div[1]/p[1]")).click();
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[2]/label/span")).click();
		driver1.findElement(By.xpath("//*[@id=\"react-autowhatever-1-section-0-item-1\"]/div/div[1]")).click();
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/label/span")).click();
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/label/span")).click();
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[3]/div[6]/div/p")).click();
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[4]/label/span")).click();
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/div[1]/div[3]/div[1]/div/div/div/div[2]/div/div[2]/div[1]/div[3]/div[4]/div[1]/div/p")).click();
		driver1.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div/div[2]/p/a")).click();
		driver1.findElement(By.xpath("//*[@id=\"rt-domrt-jrny\"]/div/div[2]/label/div[1]/span[1]/span")).click();
		driver1.findElement(By.xpath("//*[@id=\"bookbutton-RKEY:03f1ec26-a584-4fe2-9f5f-19c4d8096ad7:0~~~RKEY:03f1ec26-a584-4fe2-9f5f-19c4d8096ad7:119\"]")).click();
		
		/*System.out.println(driver1.getTitle());
		driver1.quit();
		System.setProperty("webdriver.gecko.driver","C:\\Selenium\\geckodriver.exe");
		WebDriver driver2 = new FirefoxDriver();
		driver2.get("http://www.google.com");
		System.out.println(driver2.getTitle());
		driver2.quit();*/
	}

}
