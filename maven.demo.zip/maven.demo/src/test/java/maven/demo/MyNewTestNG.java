package maven.demo;

import org.testng.annotations.Test;

public class MyNewTestNG {
	
	@Test
	public void Test1() {
		System.out.println("I am inside test1 | " +Thread.currentThread().getId());
	}
	
	@Test
	public void Test2() {
		System.out.println("I am inside test2 | " +Thread.currentThread().getId());	
	}
}
